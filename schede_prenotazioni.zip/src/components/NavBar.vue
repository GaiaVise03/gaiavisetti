<script setup>

</script>

<template>
    <nav class="navbar is-blank has-shadow is-spaced">
        <nav class="navbar" >
            <div class="navbar-start"> 
                <div class="navbar-item">
           
                </div>
            </div>
        </nav>
    </nav>

</template>