<script setup>
import { RouterLink, RouterView } from 'vue-router'
import navbar from './components/NavBar.vue'
</script>

<template>
  <navbar />

  <RouterView />
</template>
