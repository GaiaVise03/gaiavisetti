<script setup>
</script>

<template>
  <form @submit.prevent="() => alert('Login')" class="box" style="max-width: 300px; margin: auto; margin-top: 100px;">
    <input class="input mb-3" type="email" placeholder="Email" required>
    <input class="input mb-3" type="password" placeholder="Password" required>
    <button class="button is-primary is-fullwidth">Login</button>
  </form>
</template>

