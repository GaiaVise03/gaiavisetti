<script setup>
import { ref } from 'vue'

const name = ref('')
const email = ref('')
const password = ref('')

const register = () => {
  if (name.value && email.value && password.value) {
    alert(`Registrazione completata per ${name.value}`)
  } else {
    alert('Compila tutti i campi')
  }
}
</script>
<template>
  <form @submit.prevent="() => alert('Registrazione')" class="box" style="max-width: 300px; margin: auto; margin-top: 100px;">
    <input class="input mb-3" type="text" placeholder="Nome" required>
    <input class="input mb-3" type="email" placeholder="Email" required>
    <input class="input mb-3" type="password" placeholder="Password" required>
    <button class="button is-link is-fullwidth">Registrati</button>
  </form>
</template>

